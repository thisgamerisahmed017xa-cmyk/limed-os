SKIPUNZIP=1
ui_print "****************************************"
ui_print "    الروم الأسطوري المحصن - SuperRom     "
ui_print "          المطور: أحمد                  "
ui_print "****************************************"

ui_print "- جاري فك ملفات الروم بأمان..."
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'boot/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'common/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'module.prop' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'my_secure_limits.xml' -d $MODPATH >&2

ui_print "- إعطاء الصلاحيات اللازمة للسكربتات..."
set_perm_recursive $MODPATH 0 0 0755 0755

ui_print "- تم تثبيت الروم الأسطوري بنجاح! أعد تشغيل الجهاز."