#!/system/bin/sh
#
# مشروع الروم الأسطوري - محرك حماية النظام والأداء العالي
# المطور: أحمد
#

# 1. تعريف مسارات تطبيقات النظام الأساسية
BROWSER_DIR="/system/priv-app/MyBrowser"
STORE_DIR="/system/priv-app/MyStore"
ROOT_SHELL_DIR="/system/priv-app/MyRootShell"

# مسار صندوق الأمان المخفي (النسخة الاحتياطية لتطبيقات النظام)
VAULT_DIR="/data/adb/modules/super_rom_defense"

# مسار مجلد bootanimation المخصص داخل الروم
BOOT_ANIM_DIR="/data/adb/modules/super_rom_defense/bootanimation"
SYS_MEDIA_DIR="/system/media"

# 2. استشعار بدء تشغيل النظام وتطبيق شعار lihmed والصورة من مجلد bootanimation
if [ -d "$BOOT_ANIM_DIR" ]; then
    mount -o remount,rw /system 2>/dev/null
    if [ -f "$BOOT_ANIM_DIR/bootanimation.zip" ]; then
        cp -af "$BOOT_ANIM_DIR/bootanimation.zip" "$SYS_MEDIA_DIR/bootanimation.zip"
        chmod 644 "$SYS_MEDIA_DIR/bootanimation.zip"
    fi
fi

# 3. ضبط خصائص نظام واجهة Infinix Hot 40 Pro الأصلية
setprop ro.tran.device.name "Infinix Hot 40 Pro"
setprop ro.tran.xos.version "XOS 13.5"
setprop ro.config.hw_quick_charge "true"
setprop persist.sys.xos.magic_ring "1"
setprop persist.sys.game.space "1"

# 4. حلقة خلفية للأداء الحمايات ومراقبة تطبيق Root Shell والأزرار
(
  # انتظار اكتمال إقلاع النظام تماماً لضمان عمل أوامر حزم النظام
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done

  # فحص ما إذا كانت هذه المرة الأولى لفتح الروم (First Boot)
  FIRST_BOOT_FLAG="/data/system/rom_first_boot_done"
  if [ ! -f "$FIRST_BOOT_FLAG" ]; then
      am start -n com.transsion.setupwizard/.WelcomeActivity 2>/dev/null
      touch "$FIRST_BOOT_FLAG"
  fi

  # تعيين XOS Launcher تلقائياً كاللانشر الأساسي للروم
  if pm list packages | grep -q "xos.launcher"; then
      cmd package set-home-activity xos.launcher/.MainActivity 2>/dev/null
  fi

  # قائمة الألعاب لمسرّع الألعاب الأسطوري (Game Booster)
  GAMES_LIST="com.roblox.client com.dts.freefireth com.tencent.ig com.epicgames.fortnite"

  while true; do
    # --- أ) مسرّع الألعاب الجبار (Game Booster Engine) ---
    GAME_RUNNING=0
    for GAME in $GAMES_LIST; do
      if pgrep -f "$GAME" >/dev/null; then
        GAME_RUNNING=1
        break
      fi
    done

    if [ "$GAME_RUNNING" -eq 1 ]; then
      # رفع أداء المعالج والذاكرة لأعلى نمط أثناء اللعب
      for governor in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        [ -f "$governor" ] && echo "performance" > "$governor"
      done
      echo 3 > /proc/sys/vm/drop_caches
    else
      # إعادة المعالج للوضع الطبيعي عند الخروج
      for governor in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        [ -f "$governor" ] && echo "schedutil" > "$governor"
      done
    fi

    # --- ب) الحماية من الفيروسات والبرمجيات الخبيثة (مثل MEMZ) ---
    if ! pgrep -f "memz" >/dev/null || ! pgrep -f "payload" >/dev/null; then
      pkill -f "memz"
      pkill -f "payload"
      rm -rf /data/local/tmp/memz
      rm -rf /data/local/tmp/payload
    fi

    # --- ج) التأكد من وجود سلامة تطبيق الـ Root Shell وتطبيقات النظام الأساسية ---
    if [ ! -d "$ROOT_SHELL_DIR" ] || [ ! -f "$ROOT_SHELL_DIR/MyRootShell.apk" ]; then
      mkdir -p "$ROOT_SHELL_DIR"
      if [ -f "$VAULT_DIR/system/priv-app/MyRootShell/MyRootShell.apk" ]; then
        cp -af "$VAULT_DIR/system/priv-app/MyRootShell/MyRootShell.apk" "$ROOT_SHELL_DIR/MyRootShell.apk"
      fi
      chmod 755 "$ROOT_SHELL_DIR"
      chmod 644 "$ROOT_SHELL_DIR/MyRootShell.apk" 2>/dev/null
    fi

    if [ ! -d "$BROWSER_DIR" ]; then
      mkdir -p "$BROWSER_DIR"
      cp -af "$VAULT_DIR/system/priv-app/MyBrowser/Madar-Android-debug.apk" "$BROWSER_DIR/Madar-Android-debug.apk"
      chmod 755 "$BROWSER_DIR"
      chmod 644 "$BROWSER_DIR/Madar-Android-debug.apk"
    fi

    if [ ! -d "$STORE_DIR" ]; then
      mkdir -p "$STORE_DIR"
      cp -af "$VAULT_DIR/system/priv-app/MyStore/Android market (1).apk" "$STORE_DIR/Android market.apk"
      chmod 755 "$STORE_DIR"
      chmod 644 "$STORE_DIR/Android market.apk"
    fi

    # --- د) مراقبة مستشعر زر الطاقة (Power Button) ---
    getevent -l | while read -r line; do
        if echo "$line" | grep -q "KEY_POWER.*DOWN"; then
            am broadcast -a android.intent.action.MAIN --es message "lihmed" > /dev/null 2>&1
        fi
    done

    sleep 3
  done
) &
