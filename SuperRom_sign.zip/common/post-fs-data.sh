#!/system/bin/sh
# -----------------------------------------------------------------------
# مشروع الروم الأسطوري - سكربت الحماية المبكر (Early Boot Shield)
# المطور: أحمد | المستوى: مؤسسات (Enterprise)
# -----------------------------------------------------------------------

# تغيير خصائص صندوق الأمان وملفات النظام لجعلها "للقراءة فقط" مؤقتاً أثناء الإقلاع
chmod 755 /data/adb/modules/super_rom_defense
chmod 644 /data/adb/modules/super_rom_defense/module.prop

# تهيئة جدار الحماية الأولي لمنع سحب الملفات أثناء مرحلة الإقلاع الحرجة
iptables -P INPUT DROP
iptables -P FORWARD DROP

# السماح فقط بالعمليات الأساسية للنواة
iptables -A INPUT -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT
